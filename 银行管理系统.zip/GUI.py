import tkinter as tk,time
import datetime
import sqlite3
import random
import tkinter.messagebox
import pygame as py
from PIL import Image,ImageTk
win=tk.Tk()
win.title('银行管理系统')
im=Image.open("photo.jpg")
img=ImageTk.PhotoImage(im)
imglabel=tk.Label(win,image=img).pack()
win.maxsize(550,600)
win.minsize(550,600)
start_lable=tk.Label(win,text='''                                                       
             welcome to the south dust bank                 
              
              这里是南尘银行，欢迎你的到来！                 
''',font=('宋体',20))
start_lable.place(x=-110,y=290)
entry_adminuser=tk.Variable()
entry_admin=tk.Entry(win,text=entry_adminuser)
entry_adminuser.set(' ')
entry_admin.place(x=200,y=450,height=30)
entry_passwd=tk.Variable()
entry_adminpasswd=tk.Entry(win,text=entry_passwd,show='*')
entry_adminpasswd.place(x=200,y=490,height=30)
def admin_login():
    if entry_admin.get()=='南尘':
        if entry_adminpasswd.get()=='666':
            admin_log()
        else:
            tk.messagebox.askretrycancel(title='提示', message='密码错误')
    else:
        tk.messagebox.askretrycancel(title='提示',message='管理员不存在')
button_login=tk.Button(win,text='管理员登录',font=('宋体',15),command=admin_login)
button_login.place(x=210,y=405)
def update_time():
    time.configure(text=datetime.datetime.now().strftime('%Y %m %d %H %M %S'))
    time.after(1000,update_time)
time=tk.Label(win,font=('宋体',20))
time.place(x=50,y=550)
update_time()
py.mixer.init()
py.mixer.music.load(r'.\videos\sound.mp3')
py.mixer.music.play(-1, 10)
def admin_log():
    k=0
    show = tk.Toplevel()
    show.title('银行管理系统')
    show.maxsize(550, 600)
    show.minsize(550, 600)
    img = Image.open('s.jpg')
    photo = ImageTk.PhotoImage(img)
    tk.Label(show, image=photo).pack()
    tk.Label(show,text='passwd',font=('宋体',20),bg='blue').place(x=250,y=15)
    tk.Label(show,text='username',font=('宋体',20),bg='purple').place(x=90,y=15)
    User_CardId=tk.Variable()
    entry_user=tk.Entry(show,text=User_CardId,bg='red')
    entry_user.place(x=80,y=60)
    User_PassWd=tk.Variable()
    entry_mima=tk.Entry(show,text=User_PassWd,show='*',bg='yellow')
    entry_mima.place(x=230,y=60)
    def user_login():
        k = 0
        conn = sqlite3.connect('user2.db')
        c = conn.cursor()
        c.execute("create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
        for row in cursor:
            if row[0] == entry_user.get():
                cardId, cardPasswd, cardMoney, cardLock, name, IdCard, phone = row[0], row[1], row[2], row[3], row[4], \
                                                                               row[5], row[6]
                k = 1
                if entry_mima.get()==cardPasswd:
                    son_show=tk.Toplevel()
                    son_show.maxsize(300,300)
                    son_show.minsize(300,300)
                    son_show.title('银行管理系统')
                    money_save = tk.Variable()
                    money_save.set('请输入存款金额')
                    entry_savemoney = tk.Entry(son_show, text=money_save)
                    entry_savemoney.place(x=40,y=5)
                    money_get = tk.Variable()
                    money_get.set('请输入取款金额')
                    entry_getmoney = tk.Entry(son_show, text=money_get)
                    entry_getmoney.place(x=40, y=35)
                    money_EFT = tk.Variable()
                    money_EFT.set('请输入转账金额')
                    entry_EFTmoney = tk.Entry(son_show, text=money_EFT)
                    entry_EFTmoney.place(x=40, y=65)
                    money_EFTID = tk.Variable()
                    money_EFTID.set('请输入转账账户')
                    entry_EFTID = tk.Entry(son_show, text=money_EFTID)
                    entry_EFTID.place(x=40, y=95)
                    change = tk.Variable()
                    change.set('请输入新密码')
                    entry_change = tk.Entry(son_show, text=change)
                    entry_change.place(x=40,y=125)
                    tk.Label(son_show,text='你的账户余额为:').place(x=40,y=183)
                    def deposit():
                        if entry_savemoney.get()=='请输入存款金额':
                            tk.Label(son_show, text='存款金额为0').place(x=200, y=200)
                            return 0
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute("create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
                        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
                        for row in cursor:
                            if row[0] == entry_user.get():
                                cardId, cardPasswd, cardMoney, cardLock, name, IdCard, phone = row[0], row[1], row[2], \
                                                                                               row[3], row[4], \
                                                                                               row[5], row[6]
                        a = int((entry_savemoney.get()))
                        b = int(cardMoney)
                        e=a+b
                        c.execute(" update Atm set cardId='%s',cardPasswd='%s',cardMoney='%s',cardLock='%s',name='%s',IdCard='%s',phone='%s' where cardId='%s'" % (cardId, cardPasswd, e, cardLock, name, IdCard, phone,entry_user.get()))
                        tk.Label(son_show, text='存款金额为%s' % (entry_savemoney.get())).place(x=200, y=200)
                        conn.commit()
                        conn.close()
                    def withdrawal():
                        if entry_getmoney.get()=='请输入取款金额':
                            tk.Label(son_show, text='取款金额为0').place(x=200, y=220)
                            return 0
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute("create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
                        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
                        for row in cursor:
                            if row[0] == entry_user.get():
                                cardId, cardPasswd, cardMoney, cardLock, name, IdCard, phone = row[0], row[1], row[2], \
                                                                                               row[3], row[4], \
                                                                                               row[5], row[6]
                        a=int(entry_getmoney.get())
                        b = int(cardMoney)
                        if  a>b:
                            tk.messagebox.askretrycancel(title='警告', message='余额不足')
                            return 0
                        e=b-a
                        d=str(e)
                        c.execute(" update Atm set cardId='%s',cardPasswd='%s',cardMoney='%s',cardLock='%s',name='%s',IdCard='%s',phone='%s' where cardId='%s'" % (cardId, cardPasswd,d, cardLock, name, IdCard, phone, entry_user.get()))
                        tk.Label(son_show, text='取款金额为%s'%(entry_getmoney.get())).place(x=200, y=220)
                        conn.commit()
                        conn.close()
                    def EFT():
                        if entry_EFTID.get() == '请输入转账账户':
                            tk.Label(son_show, text='转账账户不能为空').place(x=180, y=250)
                            return 0
                        if entry_EFTmoney.get()=='请输入转账金额':
                            tk.Label(son_show, text='金额为0转账失败').place(x=40, y=280)
                            return 0
                        k = 0
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute("create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
                        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
                        for row in cursor:
                            if row[0] == entry_EFTID.get():
                                k = 1
                                EFT_cardId, EFT_cardPasswd, EFT_cardMoney, EFT_cardLock, EFT_name, EFT_IdCard, EFT_phone = row[0], row[1], row[2], row[3], row[4], row[5], row[6]
                        conn.close()
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute(
                            "create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
                        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
                        for row in cursor:
                            if row[0] == entry_user.get():
                              cardId, cardPasswd, cardMoney, cardLock, name, IdCard, phone = \
                                row[0], row[1], row[2], row[3], row[4], row[5], row[6]
                        if k==1:
                            a = int(entry_EFTmoney.get())
                            b = int(cardMoney)
                            if a > b:
                                tk.messagebox.askretrycancel(title='提示', message='余额不足')
                                return 0
                            e = b - a
                            d = str(e)
                            b1=int(EFT_cardMoney)
                            e1=b1+a
                            d1=str(e1)
                            c.execute(
                                " update Atm set cardId='%s',cardPasswd='%s',cardMoney='%s',cardLock='%s',name='%s',IdCard='%s',phone='%s' where cardId='%s'" % (
                                cardId, cardPasswd, d, cardLock, name, IdCard, phone, entry_user.get()))
                            c.execute(
                                " update Atm set cardId='%s',cardPasswd='%s',cardMoney='%s',cardLock='%s',name='%s',IdCard='%s',phone='%s' where cardId='%s'" % (
                                    EFT_cardId, EFT_cardPasswd, d1, EFT_cardLock, EFT_name, EFT_IdCard, EFT_phone,entry_EFTID.get()))
                            conn.commit()
                            conn.close()
                            tk.messagebox.askretrycancel(title='提示', message='已给%s成功转账%s元'%(entry_EFTID.get(),a))
                            return 0
                        if k==0:
                            tk.Label(son_show,text='账户不存在').place(x=40,y=240)
                            return 0
                    def changepasswd():
                        if entry_change.get()=='请输入新密码':
                            tk.Label(son_show,text='密码不能为空').place(x=40,y=210)
                            return 0
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute(
                            " update Atm set cardId='%s',cardPasswd='%s',cardMoney='%s',cardLock='%s',name='%s',IdCard='%s',phone='%s' where cardId='%s'" % (
                                cardId, entry_change.get(),cardMoney, cardLock, name, IdCard, phone, entry_user.get()))
                        tk.Label(son_show,text='''密码已更改为%s
                重启生效'''%(entry_change.get())).place(x=160,y=250)
                        conn.commit()
                        conn.close()
                    def kill():
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute("delete from Atm where cardId='%s'" % (entry_user.get()))
                        conn.commit()
                        conn.close()
                        son_show.destroy()
                    def query():
                        conn = sqlite3.connect('user2.db')
                        c = conn.cursor()
                        c.execute(
                            "create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
                        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
                        for row in cursor:
                            if row[0] == entry_user.get():
                                cardId, cardPasswd, cardMoney, cardLock, name, IdCard, phone = row[0], row[1], row[2], \
                                                                                               row[3], row[4], \
                                                                                               row[5], row[6]
                        tk.Label(son_show,text='%s'%(cardMoney)).place(x=130,y=183)
                        conn.commit()
                        conn.close()
                    tk.Button(son_show,text='存款',font=('宋体',10),command=deposit).place(x=200,y=3)
                    tk.Button(son_show, text='取款',font=('宋体',10),command=withdrawal).place(x=200,y=33)
                    tk.Button(son_show, text='转账',font=('宋体',10),command=EFT).place(x=200,y=83)
                    tk.Button(son_show, text='改密',font=('宋体',10),command=changepasswd).place(x=200,y=123)
                    tk.Button(son_show, text='销户',font=('宋体',10),command=kill).place(x=200,y=153)
                    tk.Button(son_show, text='查询',font=('宋体',10),command=query).place(x=200,y=183)
                else:
                    tk.Label(show, text='密码错误', font=('宋体', 20)).place(x=80, y=180)
        if k==0:
            tk.messagebox.askretrycancel(title='提示',message='账户不存在')
    def user_New():
            son_show=tk.Toplevel()
            son_show.maxsize(550, 600)
            son_show.minsize(550, 600)
            son_show.title('银行管理系统')
            img = Image.open('s.jpg')
            photo = ImageTk.PhotoImage(img)
            tk.Label(son_show, image=photo).pack()
            tk.Label(son_show,text='UserName',font=('宋体',15),bg='orange').place(x=10,y=15)
            tk.Label(son_show, text='UserId', font=('宋体', 15),bg='brown').place(x=10, y=55)
            tk.Label(son_show, text='phone', font=('宋体', 15),bg='cyan').place(x=10, y=95)
            tk.Label(son_show, text='passwd', font=('宋体', 15),bg='pink').place(x=10, y=135)
            user_name = tk.Variable()
            entry_name = tk.Entry(son_show, text=user_name,bg='pink')
            entry_name.place(x=100,y=15,height=25)
            user_Id= tk.Variable()
            entry_userId = tk.Entry(son_show, text=user_Id,bg='cyan')
            entry_userId.place(x=100,y=55,height=25)
            user_phone = tk.Variable()
            entry_phone = tk.Entry(son_show, text=user_phone,bg='brown')
            entry_phone.place(x=100,y=95,height=25)
            cardPasswd = tk.Variable()
            entry_cardPasswd = tk.Entry(son_show, text=cardPasswd,show='*',bg='orange')
            entry_cardPasswd.place(x=100,y=135,height=25)
            card_Id=randomCardId()
            card_lock='0'
            card_Money='0'
            def save():
                conn = sqlite3.connect('user2.db')
                c = conn.cursor()
                c.execute("create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
                c.execute(" insert into  Atm values ('%s','%s','%s','%s','%s','%s','%s' )"% ( card_Id, entry_cardPasswd.get(), card_Money, card_lock, entry_name.get(), entry_userId.get(),entry_phone.get()))
                conn.commit()
                conn.close()
                tk.Label(son_show,text='恭喜你注册成功，卡号为%s'%(card_Id)).place(x=80,y=150)
            button = tk.Button(son_show, text='保存', command=save)
            button.place(x=150,y=180)
            son_show.mainloop()
    def randomCardId():
        while True:
            str = ""
            for i in range(8):
                ch = chr(random.randrange(ord('0'), ord('9') + 1))
                str = str + ch
            return str
    def GUI_son():
        son_GUI=tk.Toplevel()
        son_GUI.maxsize(550, 600)
        son_GUI.minsize(550, 600)
        son_GUI.title('银行管理系统')
        im = Image.open("1.jpg")
        img = ImageTk.PhotoImage(im)
        imglabel = tk.Label(son_GUI, image=img).pack()
        tk.Label(son_GUI,text='银行系统用户如下：',font=('宋体',20)).place(x=10,y=10)
        i=40
        conn = sqlite3.connect('user2.db')
        c = conn.cursor()
        c.execute("create table if not exists Atm(cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone)")
        cursor = c.execute("SELECT cardId,cardPasswd,cardMoney,cardlock,name ,IdCard,phone from Atm")
        for row in cursor:
            tk.Label(son_GUI,text='%s'%(row[0]),font=('宋体',20),bg='orange').place(x=250,y=i)
            i=i+40
        son_GUI.mainloop()
    menubar = tk.Menu(show)
    filemenu = tk.Menu(menubar, tearoff=0)
    menubar.add_cascade(label='操作命令', menu=filemenu)
    filemenu.add_command(label='注册', command=user_New)
    filemenu.add_command(label='用户', command=GUI_son)
    filemenu.add_command(label='登录', command=user_login)
    filemenu.add_command(label='退出', command=lambda :show.destroy())
    show.config(menu=menubar)
    show.mainloop()
win.mainloop()